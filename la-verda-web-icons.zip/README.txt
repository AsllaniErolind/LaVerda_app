La Verda PWA web icons

Extract the public/ folder into your application root, merging with your existing public/ folder.

Manifest icon paths:
/icons/icon-192.png (192x192, purpose any)
/icons/icon-512.png (512x512, purpose any)

Apple touch icon:
/apple-touch-icon.png

These are not maskable icons. Do not label them maskable without reviewing safe-zone fit.

Your PWA still needs a web manifest, service worker strategy, HTTPS, and successful packaging on PWABuilder.
